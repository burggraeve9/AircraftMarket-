
<?php

namespace Modules\AircraftMarket\Models;

use Illuminate\Database\Eloquent\Model;

class AircraftOrder extends Model
{
    protected $table = 'aircraft_orders';

    protected $fillable = [
        'aircraft_id',
        'order_date',
        'delivery_date',
        'status',
    ];
}
