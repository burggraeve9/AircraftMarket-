
<?php

namespace Modules\AircraftMarket\Models;

use Illuminate\Database\Eloquent\Model;

class AircraftSale extends Model
{
    protected $table = 'aircraft_sales';

    protected $fillable = [
        'aircraft_id',
        'sale_type',
        'price',
        'condition',
        'leased_duration',
    ];
}
