
<?php

namespace Modules\AircraftMarket\Models;

use Illuminate\Database\Eloquent\Model;

class Loan extends Model
{
    protected $table = 'loans';

    protected $fillable = [
        'va_id',
        'amount',
        'interest_rate',
        'due_date',
    ];
}
