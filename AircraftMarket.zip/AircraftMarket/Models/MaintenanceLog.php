
<?php

namespace Modules\AircraftMarket\Models;

use Illuminate\Database\Eloquent\Model;

class MaintenanceLog extends Model
{
    protected $table = 'maintenance_logs';

    protected $fillable = [
        'aircraft_id',
        'contractor_id',
        'cost',
        'maintenance_type',
        'flight_hours',
    ];
}
