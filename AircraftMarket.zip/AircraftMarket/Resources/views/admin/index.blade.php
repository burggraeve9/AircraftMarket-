
@extends('layouts.admin')

@section('content')
<div class="container">
    <h2>Aircraft Market Management</h2>

    <ul class="nav nav-tabs" id="adminTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="sale-tab" data-toggle="tab" href="#sale" role="tab" aria-controls="sale" aria-selected="true">Create Sale/Lease Offer</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="maintenance-tab" data-toggle="tab" href="#maintenance" role="tab" aria-controls="maintenance" aria-selected="false">Log Maintenance</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="loan-tab" data-toggle="tab" href="#loan" role="tab" aria-controls="loan" aria-selected="false">Apply for Loan</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="order-tab" data-toggle="tab" href="#order" role="tab" aria-controls="order" aria-selected="false">Create Aircraft Order</a>
        </li>
    </ul>

    <div class="tab-content" id="adminTabContent">
        <!-- Sale/Lease Offer Form -->
        <div class="tab-pane fade show active" id="sale" role="tabpanel" aria-labelledby="sale-tab">
            <form method="POST" action="{{ route('aircraftmarket.admin.createSale') }}">
                @csrf
                <div class="form-group">
                    <label for="aircraft_id">Aircraft ID:</label>
                    <input type="text" name="aircraft_id" id="aircraft_id" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="sale_type">Sale Type:</label>
                    <select name="sale_type" id="sale_type" class="form-control" required>
                        <option value="sale">Sale</option>
                        <option value="lease">Lease</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="price">Price:</label>
                    <input type="number" step="0.01" name="price" id="price" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="condition">Condition (0-100):</label>
                    <input type="number" name="condition" id="condition" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary">Create Offer</button>
            </form>
        </div>

        <!-- Maintenance Log Form -->
        <div class="tab-pane fade" id="maintenance" role="tabpanel" aria-labelledby="maintenance-tab">
            <form method="POST" action="{{ route('aircraftmarket.admin.logMaintenance') }}">
                @csrf
                <div class="form-group">
                    <label for="aircraft_id">Aircraft ID:</label>
                    <input type="text" name="aircraft_id" id="aircraft_id" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="contractor_id">Contractor ID:</label>
                    <input type="text" name="contractor_id" id="contractor_id" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="cost">Cost:</label>
                    <input type="number" step="0.01" name="cost" id="cost" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="maintenance_type">Maintenance Type:</label>
                    <select name="maintenance_type" id="maintenance_type" class="form-control" required>
                        <option value="routine">Routine</option>
                        <option value="repair">Repair</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="flight_hours">Flight Hours:</label>
                    <input type="number" name="flight_hours" id="flight_hours" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary">Log Maintenance</button>
            </form>
        </div>

        <!-- Loan Application Form -->
        <div class="tab-pane fade" id="loan" role="tabpanel" aria-labelledby="loan-tab">
            <form method="POST" action="{{ route('aircraftmarket.admin.applyLoan') }}">
                @csrf
                <div class="form-group">
                    <label for="va_id">VA ID:</label>
                    <input type="text" name="va_id" id="va_id" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="amount">Amount:</label>
                    <input type="number" step="0.01" name="amount" id="amount" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="interest_rate">Interest Rate (%):</label>
                    <input type="number" step="0.01" name="interest_rate" id="interest_rate" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="due_date">Due Date:</label>
                    <input type="date" name="due_date" id="due_date" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary">Apply for Loan</button>
            </form>
        </div>

        <!-- Aircraft Order Form -->
        <div class="tab-pane fade" id="order" role="tabpanel" aria-labelledby="order-tab">
            <form method="POST" action="{{ route('aircraftmarket.admin.createOrder') }}">
                @csrf
                <div class="form-group">
                    <label for="aircraft_id">Aircraft ID:</label>
                    <input type="text" name="aircraft_id" id="aircraft_id" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="order_date">Order Date:</label>
                    <input type="date" name="order_date" id="order_date" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="delivery_date">Delivery Date:</label>
                    <input type="date" name="delivery_date" id="delivery_date" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary">Create Order</button>
            </form>
        </div>
    </div>
</div>
@endsection
