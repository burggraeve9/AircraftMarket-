
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAircraftOrdersTable extends Migration
{
    public function up()
    {
        Schema::create('aircraft_orders', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('aircraft_id');
            $table->date('order_date');
            $table->date('delivery_date');
            $table->enum('status', ['ordered', 'delivered']);
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('aircraft_orders');
    }
}
