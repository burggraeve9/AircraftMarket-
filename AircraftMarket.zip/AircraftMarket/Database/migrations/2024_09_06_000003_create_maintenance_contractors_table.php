
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMaintenanceContractorsTable extends Migration
{
    public function up()
    {
        Schema::create('maintenance_contractors', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->decimal('cost_factor', 5, 2); // Cost multiplier
            $table->decimal('time_factor', 5, 2); // Time multiplier
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('maintenance_contractors');
    }
}
