
<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAircraftSalesTable extends Migration
{
    public function up()
    {
        Schema::create('aircraft_sales', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('aircraft_id');
            $table->enum('sale_type', ['sale', 'lease']);
            $table->decimal('price', 15, 2);
            $table->tinyInteger('condition')->default(100); // 100% = new
            $table->integer('leased_duration')->nullable(); // in months
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('aircraft_sales');
    }
}
