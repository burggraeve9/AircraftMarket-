
<?php

// Admin routes for the Aircraft Market module
// Path: routes/admin.php
Route::group(['prefix' => 'admin/aircraftmarket', 'as' => 'aircraftmarket.admin.'], function () {
    Route::get('/', 'AdminController@index')->name('index');
    Route::post('/create-sale', 'AdminController@createSale')->name('createSale');
    Route::post('/log-maintenance', 'AdminController@logMaintenance')->name('logMaintenance');
    Route::post('/apply-loan', 'AdminController@applyLoan')->name('applyLoan');
    Route::post('/create-order', 'AdminController@createOrder')->name('createOrder');
});

