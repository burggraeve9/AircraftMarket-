
<?php

namespace Modules\AircraftMarket\Http\Controllers\Admin;

use App\Contracts\Controller;
use Illuminate\Http\Request;
use Modules\AircraftMarket\Models\AircraftSale;
use Modules\AircraftMarket\Models\MaintenanceLog;
use Modules\AircraftMarket\Models\Loan;
use Modules\AircraftMarket\Models\AircraftOrder;
use App\Models\Aircraft; // Model for the aircraft table

class AdminController extends Controller
{
    // Index method to display main admin dashboard
    public function index(Request $request)
    {
        return view('aircraftmarket::admin.index');
    }

    // Method to create new aircraft sale or lease offer
    public function createSale(Request $request)
    {
        $validated = $request->validate([
            'aircraft_id' => 'required|integer',
            'sale_type' => 'required|in:sale,lease',
            'price' => 'required|numeric',
            'condition' => 'required|integer|between:0,100',
        ]);

        AircraftSale::create($validated);
        return redirect()->route('aircraftmarket.admin.index')->with('success', 'Aircraft Sale/Lease created!');
    }

    // Method to log maintenance actions
    public function logMaintenance(Request $request)
    {
        $validated = $request->validate([
            'aircraft_id' => 'required|integer',
            'contractor_id' => 'required|integer',
            'cost' => 'required|numeric',
            'maintenance_type' => 'required|in:routine,repair',
            'flight_hours' => 'required|integer',
        ]);

        MaintenanceLog::create($validated);
        return redirect()->route('aircraftmarket.admin.index')->with('success', 'Maintenance log created!');
    }

    // Method to handle loan applications
    public function applyLoan(Request $request)
    {
        $validated = $request->validate([
            'va_id' => 'required|integer',
            'amount' => 'required|numeric',
            'interest_rate' => 'required|numeric',
            'due_date' => 'required|date',
        ]);

        Loan::create($validated);
        return redirect()->route('aircraftmarket.admin.index')->with('success', 'Loan approved!');
    }

    // Method to manage aircraft orders
    public function createOrder(Request $request)
    {
        $validated = $request->validate([
            'aircraft_id' => 'required|integer',
            'order_date' => 'required|date',
            'delivery_date' => 'required|date',
        ]);

        AircraftOrder::create($validated);
        return redirect()->route('aircraftmarket.admin.index')->with('success', 'Aircraft order created!');
    }

    // Method to handle aircraft purchase (new or used)
    public function purchaseAircraft(Request $request)
    {
        $validated = $request->validate([
            'aircraft_id' => 'required|integer',
            'buyer_id' => 'required|integer',
        ]);

        // Update the aircraft record to assign to the buyer
        $aircraft = Aircraft::find($validated['aircraft_id']);
        $aircraft->va_id = $validated['buyer_id'];  // Assign the aircraft to the buyer's VA
        $aircraft->save();

        // Remove the aircraft from the sales list
        AircraftSale::where('aircraft_id', $validated['aircraft_id'])->delete();

        return redirect()->route('aircraftmarket.admin.index')->with('success', 'Aircraft successfully purchased!');
    }

    // Method to schedule maintenance for an aircraft
    public function scheduleMaintenance(Request $request)
    {
        $validated = $request->validate([
            'aircraft_id' => 'required|integer',
            'contractor_id' => 'required|integer',
            'cost' => 'required|numeric',
            'maintenance_type' => 'required|in:routine,repair',
            'flight_hours' => 'required|integer',
        ]);

        MaintenanceLog::create([
            'aircraft_id' => $validated['aircraft_id'],
            'contractor_id' => $validated['contractor_id'],
            'cost' => $validated['cost'],
            'maintenance_type' => $validated['maintenance_type'],
            'flight_hours' => $validated['flight_hours'],
        ]);

        return redirect()->route('aircraftmarket.admin.index')->with('success', 'Maintenance scheduled!');
    }
}
